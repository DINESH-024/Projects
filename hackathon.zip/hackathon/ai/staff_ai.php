<?php
include "../config/db.php";
session_start();

if (!isset($_SESSION['staff'])) {
    die("Unauthorized");
}

$q = mysqli_query($con,
"SELECT reg_no, COUNT(*) abs
 FROM attendance
 WHERE status='A'
 GROUP BY reg_no
 HAVING abs > 5");

echo "<h3>Students with frequent absences</h3>";

while ($r = mysqli_fetch_assoc($q)) {
    echo "<p>{$r['reg_no']} – {$r['abs']} absences</p>";
}
