<?php
if (!isset($_GET['q'])) {
    echo "Ask something.";
    exit;
}

$q = strtolower($_GET['q']);
$reply = "I didn't understand that.";

if (strpos($q, "attendance") !== false) {
    $reply = "Check Dashboard → Attendance section.";
}
elseif (strpos($q, "profile") !== false) {
    $reply = "Go to Dashboard → Profile to update details.";
}
elseif (strpos($q, "hostel") !== false) {
    $reply = "Hostel details are in Dashboard → Hostel.";
}
elseif (strpos($q, "fees") !== false) {
    $reply = "Fees information is available in Fees section.";
}

echo $reply;
