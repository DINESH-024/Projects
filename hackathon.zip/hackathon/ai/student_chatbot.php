<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['student'])) {
    echo "Unauthorized";
    exit;
}

$q = strtolower(trim($_POST['message']));
$reg = $_SESSION['student'];

$response = "Sorry, I didn’t understand that 😕";

if (strpos($q, "attendance") !== false) {

    $total = mysqli_fetch_assoc(mysqli_query($con,
        "SELECT COUNT(*) c FROM attendance WHERE reg_no='$reg'"))['c'];

    $present = mysqli_fetch_assoc(mysqli_query($con,
        "SELECT COUNT(*) c FROM attendance 
         WHERE reg_no='$reg' AND status='P'"))['c'];

    $percent = $total ? round(($present/$total)*100,2) : 0;

    $response = "Your attendance is $percent%";

}
elseif (strpos($q, "profile") !== false) {
    $response = "Go to Dashboard → Profile to update your details.";
}
elseif (strpos($q, "hostel") !== false) {
    $response = "Hostel meals and bill are available in Dashboard → Hostel.";
}
elseif (strpos($q, "fees") !== false) {
    $response = "Fees details are available in Dashboard → Fees.";
}
elseif (strpos($q, "logout") !== false) {
    $response = "Click Logout on the top right corner.";
}
elseif (strpos($q, "help") !== false) {
    $response = "You can ask about attendance, profile, hostel, fees.";
}

echo $response;
