<?php
include "../config/db.php";
session_start();

if (!isset($_SESSION['student'])) {
    die("Unauthorized");
}

$reg = $_SESSION['student'];

$total = mysqli_fetch_assoc(mysqli_query($con,
"SELECT COUNT(*) c FROM attendance WHERE reg_no='$reg'"))['c'];

$present = mysqli_fetch_assoc(mysqli_query($con,
"SELECT COUNT(*) c FROM attendance WHERE reg_no='$reg' AND status='P'"))['c'];

$percent = $total ? ($present / $total) * 100 : 0;

if ($percent < 65) {
    echo "⚠ Critical shortage. Meet your class advisor immediately.";
}
elseif ($percent < 75) {
    echo "⚠ Attendance below requirement. Attend classes regularly.";
}
else {
    echo "✅ Attendance is good. Keep it up.";
}
