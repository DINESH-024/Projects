<?php
include "../config/db.php";

header("Content-Type: text/csv");
header("Content-Disposition: attachment; filename=attendance.csv");

$output = fopen("php://output", "w");
fputcsv($output, ["Reg No","Date","Period","Status"]);

$q = mysqli_query($con,"SELECT * FROM attendance");
while($r = mysqli_fetch_assoc($q)){
  fputcsv($output, $r);
}
fclose($output);
exit;
