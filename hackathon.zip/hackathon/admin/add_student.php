<?php
include "../config/db.php";
session_start();

if($_POST){
  $reg = $_POST['reg'];
  $name = $_POST['name'];
  $email = $_POST['email'];
  $pass = password_hash("admin",PASSWORD_DEFAULT);

  mysqli_query($con,
  "INSERT INTO students(reg_no,name,email,password)
   VALUES('$reg','$name','$email','$pass')");

  echo "Student added successfully";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Add Student</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
<h2>Add Student</h2>
<a href="dashboard.php" style="color:white;">Back</a>
</div>

<div class="content">
<div class="card">
<form method="post">
<input type="text" name="reg" placeholder="Register No" required><br><br>
<input type="text" name="name" placeholder="Name" required><br><br>
<input type="email" name="email" placeholder="Email" required><br><br>
<button>Add Student</button>
</form>
</div>
</div>

</body>
</html>
