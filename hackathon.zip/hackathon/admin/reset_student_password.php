<?php
include "../config/db.php";
session_start();

if($_POST){
  $reg = $_POST['reg'];
  $pass = password_hash("admin",PASSWORD_DEFAULT);

  mysqli_query($con,
  "UPDATE students SET password='$pass' WHERE reg_no='$reg'");

  echo "Password reset to default";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Reset Password</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
<h2>Reset Student Password</h2>
<a href="dashboard.php" style="color:white;">Back</a>
</div>

<div class="content">
<div class="card">
<form method="post">
<input type="text" name="reg" placeholder="Register No" required><br><br>
<button>Reset Password</button>
</form>
</div>
</div>

</body>
</html>
