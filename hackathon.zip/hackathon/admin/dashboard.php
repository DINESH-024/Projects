<?php
session_start();
if(!isset($_SESSION['admin'])){
  header("Location: ../login/admin_login.php");
  exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
<h2>Admin Dashboard</h2>
<a href="logout.php" style="color:white;">Logout</a>
</div>

<div class="container">
<div class="sidebar">
<a href="dashboard.php">Dashboard</a>
<a href="add_student.php">Add Student</a>
<a href="reset_student_password.php">Reset Password</a>
<a href="export_attendance.php">Export Attendance</a>
<a href="logs.php">System Logs</a>
</div>

<div class="content">
<div class="card">
<p>Admin controls the entire ERP system.</p>
</div>
</div>
</div>

</body>
</html>
