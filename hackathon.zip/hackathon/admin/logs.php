<?php
include "../config/db.php";
?>
<!DOCTYPE html>
<html>
<head>
<title>System Logs</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
<h2>System Logs</h2>
<a href="dashboard.php" style="color:white;">Back</a>
</div>

<div class="content">
<div class="card">
<table border="1" cellpadding="8">
<tr>
<th>User</th>
<th>Action</th>
<th>Time</th>
</tr>

<?php
$q = mysqli_query($con,"SELECT * FROM logs ORDER BY time DESC");
while($l = mysqli_fetch_assoc($q)){
  echo "<tr>
        <td>{$l['user']}</td>
        <td>{$l['action']}</td>
        <td>{$l['time']}</td>
        </tr>";
}
?>
</table>
</div>
</div>

</body>
</html>
