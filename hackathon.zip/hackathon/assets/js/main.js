/* main.js
   Common UI interactions
*/

// Smooth scroll for anchor links
document.querySelectorAll("a[href^='#']").forEach(link => {
  link.addEventListener("click", function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute("href"));
    if (target) {
      target.scrollIntoView({ behavior: "smooth" });
    }
  });
});

// Simple alert helper (used anywhere)
function showMessage(msg) {
  alert(msg);
}

// Auto-hide success messages
window.addEventListener("load", () => {
  const msg = document.getElementById("flash-message");
  if (msg) {
    setTimeout(() => {
      msg.style.display = "none";
    }, 3000);
  }
});
