function sendChat() {
    let msg = document.getElementById("chatInput").value;
    if (msg.trim() === "") return;

    let chatBox = document.getElementById("chatBox");

    chatBox.innerHTML += `<p><strong>You:</strong> ${msg}</p>`;

    fetch("../ai/student_chatbot.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "message=" + encodeURIComponent(msg)
    })
    .then(res => res.text())
    .then(reply => {
        chatBox.innerHTML += `<p><strong>Bot:</strong> ${reply}</p>`;
        chatBox.scrollTop = chatBox.scrollHeight;
    });

    document.getElementById("chatInput").value = "";
}
