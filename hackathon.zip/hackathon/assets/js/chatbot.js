/* chatbot.js
   Lightweight rule-based chatbot
*/

function askBot() {
  const input = document.getElementById("botInput");
  const output = document.getElementById("botReply");

  if (!input || !output) return;

  let q = input.value.toLowerCase().trim();
  let reply = "🤖 Sorry, I didn’t understand that.";

  if (q.includes("attendance")) {
    reply = "📊 Go to Dashboard → Attendance to check your percentage.";
  }
  else if (q.includes("profile")) {
    reply = "👤 You can update your profile in Dashboard → Profile.";
  }
  else if (q.includes("fees") || q.includes("hostel")) {
    reply = "💳 Hostel & fees details are available in Dashboard → Hostel.";
  }
  else if (q.includes("logout")) {
    reply = "🚪 Use the Logout button on the top right corner.";
  }
  else if (q.includes("help")) {
    reply = "ℹ️ Ask me about attendance, profile, hostel, or fees.";
  }

  output.innerText = reply;
  input.value = "";
}
