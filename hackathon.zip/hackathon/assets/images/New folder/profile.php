<?php
session_start();
include "../config/db.php";

// Safety: ensure student is logged in
if (!isset($_SESSION['student'])) {
    die("Unauthorized access");
}

$reg = $_SESSION['student'];
$message = "";

// 1️⃣ HANDLE PHOTO UPLOAD
if (isset($_FILES['photo'])) {

    // File type validation (SECURITY FIRST)
    $type = mime_content_type($_FILES['photo']['tmp_name']);
    if (!in_array($type, ["image/jpeg", "image/png"])) {
        die("Invalid file type. Only JPG and PNG allowed.");
    }

    // Destination path
    $path = "../assets/images/students/" . $reg . ".jpg";

    // Move uploaded file
    if (move_uploaded_file($_FILES['photo']['tmp_name'], $path)) {
        $message = "Photo uploaded successfully";
    } else {
        $message = "Upload failed. Try again.";
    }
}

// 2️⃣ DECIDE WHICH PHOTO TO SHOW
$photo = "../assets/images/students/" . $reg . ".jpg";
if (!file_exists($photo)) {
    $photo = "../assets/images/students/default.jpg";
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Student Profile</title>
</head>

<body>

    <h2>Profile Photo</h2>

    <!-- 3️⃣ DISPLAY PHOTO -->
    <img src="<?= $photo ?>" width="120" alt="Student Photo">

    <!-- SUCCESS / ERROR MESSAGE -->
    <?php if ($message): ?>
    <p><?= $message ?></p>
    <?php endif; ?>

    <!-- 4️⃣ UPLOAD FORM -->
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="photo" accept="image/*" required>
        <button type="submit">Upload Photo</button>
    </form>

</body>

</html>