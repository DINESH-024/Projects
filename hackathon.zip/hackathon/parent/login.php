<?php
session_start();
include "../config/db.php";

$error = "";

if ($_POST) {
    $reg = $_POST['reg'];
    $email = $_POST['email'];

    $q = mysqli_query($con,
      "SELECT * FROM parents WHERE reg_no='$reg' AND email='$email'"
    );

    if (mysqli_num_rows($q) == 1) {
        $_SESSION['parent'] = $reg;
        header("Location: attendance_view.php");
        exit;
    } else {
        $error = "Invalid details";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Parent Login</title>
<link rel="stylesheet" href="../assets/css/login.css">
</head>
<body>

<div class="login-box">
<h2>Parent Login</h2>

<?php if ($error) echo "<p style='color:red'>$error</p>"; ?>

<form method="post">
  <input type="text" name="reg" placeholder="Student Register No" required>
  <input type="email" name="email" placeholder="Parent Email" required>
  <button type="submit">Login</button>
</form>

</div>
</body>
</html>
