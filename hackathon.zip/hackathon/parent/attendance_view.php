<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['parent'])) {
    header("Location: login.php");
    exit;
}

$reg = $_SESSION['parent'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Attendance View</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
<h2>Attendance – <?= $reg ?></h2>
<a href="login.php" style="color:white;">Logout</a>
</div>

<div class="content">
<div class="card">

<table border="1" cellpadding="8">
<tr>
<th>Date</th>
<th>Period</th>
<th>Status</th>
</tr>

<?php
$q = mysqli_query($con,
"SELECT * FROM attendance WHERE reg_no='$reg' ORDER BY date DESC");

while($r = mysqli_fetch_assoc($q)){
  $cls = $r['status']=="P"?"present":($r['status']=="A"?"absent":"od");
  echo "<tr>
        <td>{$r['date']}</td>
        <td>{$r['period']}</td>
        <td class='$cls'>{$r['status']}</td>
        </tr>";
}
?>
</table>

</div>
</div>

</body>
</html>
