<?php include "config/constants.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo COLLEGE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/main.css">
</head>

<body>

    <video autoplay muted loop id="bgVideo">
        <source src="assets/videos/campus.mp4" type="video/mp4">
    </video>

    <div class="overlay">
        <h1><?php echo COLLEGE_NAME; ?></h1>
        <p>Department of Data Science</p>

        <div class="buttons">
            <a href="login/student_login.php">Student Login</a>
            <a href="login/staff_login.php">Staff Login</a>
        </div>

        <div class="gallery">
            <img src="assets/images/college/campus1.jpg">
            <img src="assets/images/college/campus2.jpg">
            <img src="assets/images/college/lab.jpg">
        </div>


    </div>

</body>

</html>