<?php
include "../middleware/auth.php";
studentAuth();
include "../config/db.php";

$reg = $_SESSION['student'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Student Dashboard</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
  <h2>Welcome, <?= $reg ?></h2>
  <a href="logout.php" style="color:white;">Logout</a>
</div>

<div class="container">
  <div class="sidebar">
    <a href="dashboard.php">Dashboard</a>
    <a href="profile.php">Profile</a>
    <a href="attendance.php">Attendance</a>
    <a href="hostel.php">Hostel</a>
    <a href="fees.php">Fees</a>
  </div>

  <div class="content">
    <div class="card" style="margin-top:20px;">
  <h3>🤖 Student Assistant</h3>

  <div id="chatBox" style="
    height:200px;
    overflow-y:auto;
    border:1px solid #ccc;
    padding:10px;
    margin-bottom:10px;
    background:#fff;
  ">
    <p><strong>Bot:</strong> Hi! Ask me about attendance, profile, hostel, fees.</p>
  </div>

  <input type="text" id="chatInput"
         placeholder="Ask something..."
         style="width:75%; padding:8px;">
  <button onclick="sendChat()">Send</button>
</div>

    <div class="card">
      <h3>Student Dashboard</h3>
      <p>Use the menu to view your academic details.</p>
    </div>
  </div>
</div>

</body>
</html>
