<?php
session_start();
session_destroy();
header("Location: ../login/student_login.php");
exit;
