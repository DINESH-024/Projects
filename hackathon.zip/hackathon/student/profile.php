<?php
include "../middleware/auth.php";
studentAuth();

$reg = $_SESSION['student'];
$photo = "../assets/images/students/$reg.jpg";
if (!file_exists($photo)) {
    $photo = "../assets/images/students/default.jpg";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Profile</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
  <h2>Profile</h2>
  <a href="dashboard.php" style="color:white;">Back</a>
</div>

<div class="content">
  <div class="card">
    <img src="<?= $photo ?>" width="120"><br><br>

    <form method="post" enctype="multipart/form-data">
      <input type="file" name="photo" required>
      <button type="submit">Upload</button>
    </form>

    <?php
    if (isset($_FILES['photo'])) {
        $type = mime_content_type($_FILES['photo']['tmp_name']);
        if (in_array($type, ["image/jpeg","image/png"])) {
            move_uploaded_file(
              $_FILES['photo']['tmp_name'],
              "../assets/images/students/$reg.jpg"
            );
            echo "<p>Photo updated</p>";
        }
    }
    ?>
  </div>
</div>

</body>
</html>
