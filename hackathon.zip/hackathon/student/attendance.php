<?php
include "../middleware/auth.php";
studentAuth();
include "../config/db.php";

$reg = $_SESSION['student'];

$total = mysqli_fetch_assoc(mysqli_query($con,
"SELECT COUNT(*) c FROM attendance WHERE reg_no='$reg'"))['c'];

$present = mysqli_fetch_assoc(mysqli_query($con,
"SELECT COUNT(*) c FROM attendance WHERE reg_no='$reg' AND status='P'"))['c'];

$percent = $total ? round(($present/$total)*100,2) : 0;
?>
<!DOCTYPE html>
<html>
<head>
<title>Attendance</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
<h2>Attendance</h2>
<a href="dashboard.php" style="color:white;">Back</a>
</div>

<div class="content">
<div class="card">
<h3>Attendance Percentage</h3>
<p class="<?= $percent < 75 ? 'absent' : 'present' ?>">
<?= $percent ?>%
</p>

<hr>

<?php
$q = mysqli_query($con,
"SELECT * FROM attendance WHERE reg_no='$reg' ORDER BY date DESC");

while($row = mysqli_fetch_assoc($q)){
  $cls = $row['status']=="P"?"present":($row['status']=="A"?"absent":"od");
  echo "<p class='$cls'>
        {$row['date']} | Period {$row['period']} | {$row['status']}
        </p>";
}
?>
</div>
</div>

</body>
</html>
