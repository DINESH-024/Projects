<?php
include "../middleware/auth.php";
studentAuth();
?>
<!DOCTYPE html>
<html>
<head>
<title>Fees</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
<h2>Fees</h2>
<a href="dashboard.php" style="color:white;">Back</a>
</div>

<div class="content">
<div class="card">
<p>Tuition Fees: ₹45,000</p>
<p>Hostel Fees: Calculated from meals</p>
<p>Status: Pending</p>
</div>
</div>

</body>
</html>
