<?php
include "../middleware/auth.php";
studentAuth();
include "../config/db.php";

$reg = $_SESSION['student'];
?>
<!DOCTYPE html>
<html>

<head>
    <title>Hostel</title>
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>

<body>

    <div class="header">
        <h2>Hostel Meals</h2>
        <a href="dashboard.php" style="color:white;">Back</a>
    </div>

    <div class="content">
        <div class="card">

            <form method="post">
                <select name="meal">
                    <option value="BF">Breakfast</option>
                    <option value="LUNCH">Lunch</option>
                    <option value="DINNER">Dinner</option>
                </select>
                <button>Add Meal</button>
            </form>

            <?php
$prices = ['BF'=>30,'LUNCH'=>60,'DINNER'=>60];

if ($_POST) {
  $meal = $_POST['meal'];
  mysqli_query($con,
   "INSERT INTO hostel_log(reg_no,meal,amount,date)
    VALUES('$reg','$meal','".$prices[$meal]."',CURDATE())");
}

$q = mysqli_query($con,
"SELECT * FROM hostel_log WHERE reg_no='$reg'");
$total = 0;
while($r = mysqli_fetch_assoc($q)){
  echo "<p>{$r['date']} - {$r['meal']} - ₹{$r['amount']}</p>";
  $total += $r['amount'];
}
echo "<hr><strong>Total: ₹$total</strong>";
?>

        </div>
    </div>

</body>

</html>