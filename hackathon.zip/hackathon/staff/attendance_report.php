<?php
include "../middleware/auth.php";
staffAuth();
include "../config/db.php";
?>
<!DOCTYPE html>
<html>
<head>
<title>Attendance Report</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
<h2>Attendance Report</h2>
<a href="dashboard.php" style="color:white;">Back</a>
</div>

<div class="content">
<div class="card">

<table border="1" cellpadding="8">
<tr>
<th>Reg No</th>
<th>Date</th>
<th>Period</th>
<th>Status</th>
</tr>

<?php
$q = mysqli_query($con,"SELECT * FROM attendance ORDER BY date DESC");
while($r = mysqli_fetch_assoc($q)){
  echo "<tr>
        <td>{$r['reg_no']}</td>
        <td>{$r['date']}</td>
        <td>{$r['period']}</td>
        <td>{$r['status']}</td>
        </tr>";
}
?>
</table>

</div>
</div>

</body>
</html>
