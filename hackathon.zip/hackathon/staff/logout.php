<?php
session_start();
session_destroy();
header("Location: ../login/staff_login.php");
exit;
