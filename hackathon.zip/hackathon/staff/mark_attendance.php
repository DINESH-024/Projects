<?php
include "../middleware/auth.php";
staffAuth();
include "../config/db.php";

$date = date("Y-m-d");
?>
<!DOCTYPE html>
<html>
<head>
<title>Mark Attendance</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
<h2>Mark Attendance</h2>
<a href="dashboard.php" style="color:white;">Back</a>
</div>

<div class="content">
<div class="card">

<form method="post">
<label>Date:</label>
<input type="date" name="date" value="<?= $date ?>" required>

<label>Period:</label>
<input type="number" name="period" min="1" max="8" required>

<table border="1" cellpadding="8">
<tr>
<th>Register No</th>
<th>Status</th>
</tr>

<?php
$q = mysqli_query($con,"SELECT reg_no FROM students");
while($s = mysqli_fetch_assoc($q)){
?>
<tr>
<td><?= $s['reg_no'] ?></td>
<td>
<select name="status[<?= $s['reg_no'] ?>]">
<option value="P">Present</option>
<option value="A">Absent</option>
<option value="OD">OD</option>
</select>
</td>
</tr>
<?php } ?>
</table>

<br>
<button type="submit">Save Attendance</button>
</form>

<?php
if($_POST){
  foreach($_POST['status'] as $reg=>$stat){
    mysqli_query($con,
    "INSERT INTO attendance(reg_no,date,period,status)
     VALUES('$reg','".$_POST['date']."','".$_POST['period']."','$stat')");
  }
  echo "<p>Attendance saved successfully</p>";
}
?>

</div>
</div>

</body>
</html>
