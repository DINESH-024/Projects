<?php
include "../middleware/auth.php";
staffAuth();
?>
<!DOCTYPE html>
<html>
<head>
<title>Staff Dashboard</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<div class="header">
  <h2>Staff Dashboard</h2>
  <a href="logout.php" style="color:white;">Logout</a>
</div>

<div class="container">
  <div class="sidebar">
    <a href="dashboard.php">Dashboard</a>
    <a href="mark_attendance.php">Mark Attendance</a>
    <a href="attendance_report.php">Attendance Report</a>
  </div>

  <div class="content">
    <div class="card">
      <h3>Welcome Staff</h3>
      <p>Select an option from the menu.</p>
    </div>
  </div>
</div>

</body>
</html>
