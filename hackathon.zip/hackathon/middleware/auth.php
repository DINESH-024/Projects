<?php
session_start();

function studentAuth() {
    if (!isset($_SESSION['student'])) {
        header("Location: ../login/student_login.php");
        exit;
    }
}

function staffAuth() {
    if (!isset($_SESSION['staff'])) {
        header("Location: ../login/staff_login.php");
        exit;
    }
}
