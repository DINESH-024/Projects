<?php include "config/constants.php"; ?>
<!DOCTYPE html>
<html>
<head>
<title>Contact | <?php echo COLLEGE_NAME; ?></title>
<link rel="stylesheet" href="assets/css/main.css">
</head>
<body>

<h1>Contact Us</h1>

<p><strong>Email:</strong> <?php echo COLLEGE_EMAIL; ?></p>
<p><strong>Phone:</strong> +91 98765 43210</p>
<p><strong>Address:</strong> Chennai, Tamil Nadu, India</p>

<hr>

<h3>Send a Message</h3>
<form method="post">
  <input type="text" name="name" placeholder="Your Name" required><br><br>
  <input type="email" name="email" placeholder="Your Email" required><br><br>
  <textarea name="msg" placeholder="Message" required></textarea><br><br>
  <button type="submit">Send</button>
</form>

<?php
if($_POST){
  echo "<p>Thank you. We will contact you soon.</p>";
}
?>

<a href="index.php">← Back to Home</a>

</body>
</html>
