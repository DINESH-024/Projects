CREATE DATABASE college_erp;
USE college_erp;

-- STUDENTS
CREATE TABLE students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reg_no VARCHAR(20) UNIQUE,
  name VARCHAR(100),
  email VARCHAR(100),
  password VARCHAR(255)
);

-- STAFF
CREATE TABLE staff (
  id INT AUTO_INCREMENT PRIMARY KEY,
  staff_id VARCHAR(50),
  name VARCHAR(100),
  password VARCHAR(255)
);

-- PARENTS
CREATE TABLE parents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reg_no VARCHAR(20),
  email VARCHAR(100),
  phone VARCHAR(15)
);

-- ATTENDANCE
CREATE TABLE attendance (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reg_no VARCHAR(20),
  date DATE,
  period INT,
  status ENUM('P','A','OD')
);

-- HOSTEL
CREATE TABLE hostel_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reg_no VARCHAR(20),
  meal ENUM('BF','LUNCH','DINNER'),
  amount INT,
  date DATE
);

-- ADMIN
CREATE TABLE admin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  password VARCHAR(255)
);

-- SYSTEM LOGS (DB copy)
CREATE TABLE logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user VARCHAR(50),
  action TEXT,
  time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
