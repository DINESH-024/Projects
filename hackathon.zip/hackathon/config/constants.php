<?php
// College details
define("COLLEGE_NAME", "Smart College of Data Science");
define("COLLEGE_EMAIL", "info@smartcollege.edu");

// Attendance rules
define("MIN_ATTENDANCE", 75);

// Fees
define("HOSTEL_BREAKFAST_FEE", 30);
define("HOSTEL_LUNCH_FEE", 60);
define("HOSTEL_DINNER_FEE", 60);

// Environment
define("BASE_URL", "http://localhost/college-erp/");
?>