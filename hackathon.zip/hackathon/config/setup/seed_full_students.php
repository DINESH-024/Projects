<?php
include "../config/db.php";

$students = [
 ['25PDS001','A. Subramaniya Raju'],
 ['25PDS002','Abishek Noyell A'],
 ['25PDS004','Akshaya V'],
 ['25PDS005','S. Angelin Zilpah'],
 ['25PDS006','Anupriya K'],
 ['25PDS007','Arulsurya S P'],
 ['25PDS008','Balaganesan M L'],
 ['25PDS009','Balaji A'],
 ['25PDS011','Bhagirathi P'],
 ['25PDS012','Dinesh'],                 // YOU 😎
 ['25PDS014','Harieshwaran M'],
 ['25PDS015','Iswarya M'],
 ['25PDS016','Jasmine Ruby C'],
 ['25PDS017','Jaya Susee J K'],
 ['25PDS018','S. Kannan'],
 ['25PDS019','B. Karthiga'],
 ['25PDS020','Kavi Mithra M'],
 ['25PDS022','Kirustika S'],
 ['25PDS023','Kothai Nayaki K P'],
 ['25PDS024','M. Nagaruban'],
 ['25PDS025','Masthan Ali S'],
 ['25PDS028','Mose Maxon A'],
 ['25PDS029','Mugesh Kumar G'],
 ['25PDS032','R. Priyadharshini'],
 ['25PDS033','A. Rahul'],
 ['25PDS040','Sunil P'],
 ['25PDS042','Velmurugan C'],
 ['25PDS043','Yusuf Khan J']
];

foreach ($students as $s) {
    $reg   = $s[0];
    $name  = $s[1];
    $email = strtolower($reg)."@americancollege.edu.in";
    $pass  = password_hash("admin", PASSWORD_DEFAULT);

    mysqli_query($con,
      "INSERT INTO students (reg_no,name,email,password)
       VALUES ('$reg','$name','$email','$pass')"
    );
}

echo "✅ ALL STUDENT RECORDS INSERTED SUCCESSFULLY";
