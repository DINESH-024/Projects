<?php
// seed_staff.php
include "../db.php";

$staff = [
 ['HOD001','Dr. J. Frank Reuban Jebaraj','HOD','frank@americancollege.edu.in'],
 ['INC001','Dr. D. Senthilkumar','INCHARGE','senthilkumar@americancollege.edu.in'],
 ['STF001','Dr. S. Navin Prasad','STAFF','navinprasad@americancollege.edu.in'],
 ['STF002','Ms. A. Dhanalakshmi','STAFF','dhanalakshmi@americancollege.edu.in'],
 ['STF003','Mr. Palani Kumar','STAFF','palanikumar@americancollege.edu.in'],
 ['STF004','Ms. Sangeetha','STAFF','sangeetha@americancollege.edu.in']
];

foreach ($staff as $s) {
    $staff_id = $s[0];
    $name     = $s[1];
    $role     = $s[2];
    $email    = $s[3];
    $password = password_hash("admin", PASSWORD_DEFAULT);

    // remove old record if exists (safe)
    mysqli_query($con, "DELETE FROM staff WHERE staff_id='$staff_id'");

    // insert fresh record
    mysqli_query($con,
      "INSERT INTO staff (staff_id, name, role, email, password)
       VALUES ('$staff_id','$name','$role','$email','$password')"
    );
}

echo "✅ Staff data seeded successfully";