<?php
include "../config/db.php";
header("Content-Type: application/json");

if (!isset($_GET['reg'])) {
    echo json_encode(["error" => "Register number required"]);
    exit;
}

$reg = $_GET['reg'];

$q = mysqli_query($con,
"SELECT SUM(amount) AS total
 FROM hostel_log
 WHERE reg_no='$reg'");

$row = mysqli_fetch_assoc($q);

echo json_encode([
  "reg_no" => $reg,
  "total_amount" => $row['total'] ?? 0
]);
