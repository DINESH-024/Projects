<?php
include "../config/db.php";

header("Content-Type: application/json");

if (!isset($_GET['reg'])) {
    echo json_encode(["error" => "Register number required"]);
    exit;
}

$reg = $_GET['reg'];

$data = [];
$q = mysqli_query($con,
"SELECT date, period, status
 FROM attendance
 WHERE reg_no='$reg'
 ORDER BY date DESC");

while ($row = mysqli_fetch_assoc($q)) {
    $data[] = $row;
}

echo json_encode($data);
