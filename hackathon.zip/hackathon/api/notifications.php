<?php
include "../config/db.php";

function sendAbsentNotification($reg) {

    $q = mysqli_query($GLOBALS['con'],
      "SELECT p.email
       FROM parents p
       WHERE p.reg_no='$reg'");

    $row = mysqli_fetch_assoc($q);

    if ($row) {
        $msg = "Your ward ($reg) was marked absent today.";
        mail($row['email'], "Attendance Alert", $msg);
        return true;
    }
    return false;
}
