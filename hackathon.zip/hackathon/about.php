<?php include "config/constants.php"; ?>
<!DOCTYPE html>
<html>
<head>
<title>About | <?php echo COLLEGE_NAME; ?></title>
<link rel="stylesheet" href="assets/css/main.css">
</head>
<body>

<h1>About <?php echo COLLEGE_NAME; ?></h1>

<p>
<?php echo COLLEGE_NAME; ?> is committed to excellence in
Data Science education, combining traditional academics
with AI-driven innovation.
</p>

<p>
Our mission is to prepare students for real-world challenges
through practical learning, smart systems, and ethical values.
</p>

<a href="index.php">← Back to Home</a>

</body>
</html>
