<?php
session_start();
include "../config/db.php";

$msg = "";

if ($_POST) {
    $newpass = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $reg = $_SESSION['reset_user'];

    mysqli_query($con,
      "UPDATE students SET password='$newpass' WHERE reg_no='$reg'"
    );

    session_destroy();
    header("Location: student_login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Reset Password</title>
<link rel="stylesheet" href="../assets/css/login.css">
</head>
<body>

<div class="login-box">
<h2>Reset Password</h2>

<form method="post">
  <input type="password" name="password" placeholder="New Password" required>
  <button type="submit">Update Password</button>
</form>

</div>

</body>
</html>
