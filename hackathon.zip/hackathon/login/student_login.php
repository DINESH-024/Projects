<?php
session_start();
include "../config/db.php";

$error = "";

if ($_POST) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $q = mysqli_query($con, "SELECT * FROM students WHERE reg_no='$username'");
    $row = mysqli_fetch_assoc($q);

    if ($row && password_verify($password, $row['password'])) {
        $_SESSION['student'] = $username;
        header("Location: ../student/dashboard.php");
        exit;
    } else {
        $error = "Invalid username or password";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Student Login</title>
<link rel="stylesheet" href="../assets/css/login.css">
</head>
<body>

<div class="login-box">
<h2>Student Login</h2>

<?php if ($error) echo "<p style='color:red'>$error</p>"; ?>

<form method="post">
  <input type="text" name="username" placeholder="Register No" required>
  <input type="password" name="password" placeholder="Password" required>
  <button type="submit">Login</button>
</form>

<a href="forgot_password.php">Forgot Password?</a>
</div>

</body>
</html>
