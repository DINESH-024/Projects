<?php
session_start();
include "../config/db.php";

$msg = "";

if ($_POST) {
    $reg = $_POST['username'];

    $q = mysqli_query($con, "SELECT email FROM students WHERE reg_no='$reg'");
    $row = mysqli_fetch_assoc($q);

    if ($row) {
        $otp = rand(100000, 999999);
        $_SESSION['otp'] = $otp;
        $_SESSION['reset_user'] = $reg;

        mail($row['email'], "OTP for Password Reset", "Your OTP is $otp");

        header("Location: otp_verify.php");
        exit;
    } else {
        $msg = "User not found";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Forgot Password</title>
<link rel="stylesheet" href="../assets/css/login.css">
</head>
<body>

<div class="login-box">
<h2>Forgot Password</h2>

<?php if ($msg) echo "<p style='color:red'>$msg</p>"; ?>

<form method="post">
  <input type="text" name="username" placeholder="Register No" required>
  <button type="submit">Send OTP</button>
</form>

</div>

</body>
</html>
