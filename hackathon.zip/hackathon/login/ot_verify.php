<?php
session_start();

$error = "";

if ($_POST) {
    if ($_POST['otp'] == $_SESSION['otp']) {
        header("Location: reset_password.php");
        exit;
    } else {
        $error = "Invalid OTP";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>OTP Verification</title>
<link rel="stylesheet" href="../assets/css/login.css">
</head>
<body>

<div class="login-box">
<h2>Verify OTP</h2>

<?php if ($error) echo "<p style='color:red'>$error</p>"; ?>

<form method="post">
  <input type="text" name="otp" placeholder="Enter OTP" required>
  <button type="submit">Verify</button>
</form>

</div>

</body>
</html>
