<?php
session_start();
include "../config/db.php";

$error = "";

if ($_POST) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $q = mysqli_query($con, "SELECT * FROM staff WHERE staff_id='$username'");
    $row = mysqli_fetch_assoc($q);

    if ($row && password_verify($password, $row['password'])) {
        $_SESSION['staff'] = $username;
        header("Location: ../staff/dashboard.php");
        exit;
    } else {
        $error = "Invalid login details";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Staff Login</title>
<link rel="stylesheet" href="../assets/css/login.css">
</head>
<body>

<div class="login-box">
<h2>Staff Login</h2>

<?php if ($error) echo "<p style='color:red'>$error</p>"; ?>

<form method="post">
  <input type="text" name="username" placeholder="Staff ID" required>
  <input type="password" name="password" placeholder="Password" required>
  <button type="submit">Login</button>
</form>

</div>

</body>
</html>
